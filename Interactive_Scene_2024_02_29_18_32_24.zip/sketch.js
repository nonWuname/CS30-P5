//   Interactive Scene
//   Luke Wu
//   Feb 12, 2024
// a assignment for mark, a non-aesthtic art.


let follow_shape_size = 8 // the size of the combo shape

// variable below allow me to do framecount
let time = 0;  

//variable for two auto triangle, the size will be the same for both, 
let x_auto = 0 , y_auto = 0 , size_auto = 8 ;
let x_auto_a = 0 , y_auto_a = -12;

let bool_auto_change = true 
// two situation for the auto triangle,true (continue the movement) , false(vanish)

let stage_change = 0; //for the scene change, 0,1,2. total is three stage

let bool_head_tail = true;  //set for the head_tail, for the swirl


function setup() {
  //setup function
  createCanvas(600,600);
}


function auto_shape(x ,y ,size_change)
{
  //draw a shape automatically move, x for x_postion , y for y axis, size_change mean size
  stroke((x+y)%255,(x+size_change/2 + y+size_change/2)%255,(x+size_change + y)%255);
  fill(x%255,y%255,(x+y+size_change)%255);
  
  triangle(x,y,x+size_change/2,y+size_change/2,x+size_change,y);
  
}

function combo_shape(x)
{
  //draw a combination of shape i want,x is turn of swirl, swirl is a function, follow the mouse
  
  strokeWeight(2);
  fill(mouseX % 255 , mouseY % 255, (mouseY + mouseX) % 255 )
  
  swirl(mouseX , mouseY,x,'ci','rd',bool_head_tail);
  swirl(mouseX , mouseY,x,'ci','ru',bool_head_tail);
  swirl(mouseX , mouseY,x,'ci','ld',bool_head_tail);
  swirl(mouseX , mouseY,x,'ci','lu',bool_head_tail);

}



function mousePressed()
{
  //  once mousepressed and it is center, the scene change
  
  
  if(mouseButton === CENTER)
    {
      stage_change++;
      if(stage_change === 4)
      {
      stage_change = 0;
      }
    }
  
  if(bool_head_tail)
    {
      bool_head_tail = false;
    }
  else if(!bool_head_tail)
    {
      bool_head_tail = true;
    }
  
}


function keyPressed()
{
  //whatever the key pressed, the auto shape is either exist or disappear,but need click canvas first
  if( bool_auto_change )
    {
      bool_auto_change = false;
    }
  else if( !bool_auto_change)
    {
      bool_auto_change = true;
    }

}

function signature()
{
  //sign my name
  textSize(20);
  stroke(0);
  text("LUKE WU", width-140 , height -10);
}



function swirl( x_pos,y_pos,turns,shape_used,direction,head_or_tail)
{
  // a function draw a combo shape, x_pos is a position for x, y_pos for y, turns mean how many loop, shape_usde mean what shape to use. direction mean what direction to draw such as lu = left up. tail or head suppose be a boolean, true draw the head first, false draw the tail first
  
  current_x_pos = x_pos;
  current_y_pos = y_pos;
  strokeWeight(4);
  
  

  //the code below use the parameter to draw the graph, all the if statement is to see what to draw
  
  
  for( let i = 0 , j = turns; i < turns , j > 0; i++ , j-- )
  {
    stroke(current_x_pos % 255 , current_y_pos % 255, (current_x_pos + current_y_pos) %255);
    fill(255);
    if(shape_used === 'sq')
    {
      if(head_or_tail === false)
        {
          square(current_x_pos,current_y_pos,i);
        }
      else if(head_or_tail === true)
        {
          square(current_x_pos,current_y_pos,j);
        }
    }
    if(shape_used === 'ci')
    {
      if(head_or_tail === false)
        {
          circle(current_x_pos,current_y_pos,i);
        }
      else if(head_or_tail === true)
        {
          circle(current_x_pos,current_y_pos,j);
        }
    }
    if(direction === 'lu')
      {
        current_x_pos -= i;
        current_y_pos -= j;
      }
    if(direction === 'rd')
      {
        current_x_pos += i;
        current_y_pos += j;
      }

    if(direction === 'ru')
      {
        current_x_pos += i;
        current_y_pos -= j;
      }
    if(direction === 'ld')
      {
        current_x_pos -= i;
        current_y_pos += j;
      }
    
  }
  
}



function draw() {
  // main function, draw the graph i want  

  background(255,229,204);
  time++;

    
  
  signature();
  
  if(y_auto_a < 0)
    {
      y_auto_a = height;
    }
  

  
  combo_shape(follow_shape_size);

  if(follow_shape_size > 15)
    {
      follow_shape_size = 8;
    }
  
  //each stage will draw diferent graph
  if(stage_change === 0 )
  { 
    swirl(0,0,32,'sq','rd',bool_head_tail);
    swirl(width,height,32,'ci','lu',bool_head_tail);
    swirl(0,height,32,'sq','ru',!bool_head_tail);
    swirl(width,0,32,'ci','ld',!bool_head_tail);
  }
  
  
  if(stage_change === 1)
  { 
    swirl(width/2,height/2,24,'ci','rd',bool_head_tail);
    swirl(width/2,height/2,24,'sq','lu',!bool_head_tail);
    swirl(width/2,height/2,24,'ci','ru',bool_head_tail);
    swirl(width/2,height/2,24,'sq','ld',!bool_head_tail);
  }
  
  
  if(stage_change === 2)
  { 
    swirl(mouseX -100,mouseY -100,14,'sq','lu',bool_head_tail);
    swirl(mouseX +100,mouseY -100,14,'sq','ru',!bool_head_tail);
    swirl(mouseX +100,mouseY +100,14,'sq','rd',!bool_head_tail);
    swirl(mouseX -100,mouseY +100,14,'sq','ld',bool_head_tail);
  }
  
  if(stage_change === 3)
  { 
    swirl(mouseX -100,mouseY -100,14,'sq','lu',bool_head_tail);
    swirl(mouseX +100,mouseY -100,14,'sq','ru',bool_head_tail);
    swirl(mouseX ,mouseY+100 ,14,'sq','rd',bool_head_tail);
    swirl(mouseX ,mouseY+100 ,14,'sq','ld',bool_head_tail);
  }
  
  
  
  
  
  if(bool_auto_change)
  {
    auto_shape(x_auto,y_auto,size_auto);
    auto_shape(x_auto_a , y_auto_a, size_auto);

    x_auto ++ ; y_auto +=2;

    x_auto_a ++; y_auto_a -=2;

    if( x_auto > width && y_auto > height)
      {
        x_auto = 0;
        y_auto = 0;
        size_auto = 8;
      }
    if( x_auto_a > width)
    {
      x_auto_a = 0;
    }
    size_auto ++;
  }


    
  
  if(time % 20===0)
  {
    follow_shape_size++;
  }
  
}